//
//  TodoItemCell.swift
//  TableView
//
//  Created by user151738 on 4/4/19.
//  Copyright © 2019 user151738. All rights reserved.
//

import Foundation



import UIKit

class TodoItemCell: UITableViewCell {
    
    var isCompleted: Bool = false{
        didSet {
            guard let currentText = textLabel?.text else { return }
            
            let strikeStyle = isCompleted ? NSNumber(value: NSUnderlineStyle.single.rawValue) : NSNumber(value: 0)
            let strokeEffect: [NSAttributedString.Key: Any] = [.strikethroughStyle: strikeStyle, .strikethroughColor: UIColor.black]
            
            textLabel?.attributedText = NSAttributedString(string: currentText, attributes: strokeEffect)
        }
    }
}
