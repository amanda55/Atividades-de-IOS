//
//  ViewController.swift
//  Exercicio03
//
//  Created by user151738 on 3/26/19.
//  Copyright © 2019 user151738. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var birthdateTextField: UILabel!
    @IBOutlet weak var ageLabel: UITextField!
    enum AgeError: Error {
        case emptyText
        case invalidFormat
        case invalidDate
        case futureBirthDay
        case unknow
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func actionButtonDidTap(_ sender: Any) {
        do{
             let age = try CalculaAge(from: ageLabel.text ?? "", dateFormat: "dd/MM/yyyy")
            birthdateTextField.text = 	String(age)
        }
        catch AgeError.emptyText{
            birthdateTextField.text = "Digite a idade"
        }
        catch AgeError.futureBirthDay{
            birthdateTextField.text = "Prevendo o futuro"
        }
        catch AgeError.invalidFormat{
            birthdateTextField.text = "Formato Inválido"
        }
        catch AgeError.invalidDate{
            birthdateTextField.text = "Data Inválida"
        }
        catch {
            birthdateTextField.text = "Erro desconhecido"
        }
    }
    
    private func CalculaAge(from text: String, dateFormat: String    ) throws -> Int{
        if text.isEmpty{
            throw AgeError.emptyText
        }
        
        if text.count != dateFormat.count{
            throw AgeError.invalidFormat
        }
        
        let FormatDate = DateFormatter()
        FormatDate.dateFormat =  dateFormat
        
        let data = FormatDate.date(from: text)
        
        if data == nil {
            throw AgeError.invalidDate
        }
        
        if data! > Date(){
            throw AgeError.futureBirthDay
        }
        
        let age = Calendar.current.dateComponents([Calendar.Component.year], from: data!, to: Date()).year
        
        if age == nil{
            throw AgeError.unknow
        }
        
        return age!
    }
}


