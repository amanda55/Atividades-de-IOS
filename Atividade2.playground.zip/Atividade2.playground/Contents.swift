enum BankOperation{
    
    case withdrawl(value:Double)
    case deposit (from: String, value: Double)
}

protocol BankAccountProtocol{
    //Initializers
    init(number: String, holder: String)
    
    //Properties
    
    var balance: Double {get}
    var statement: [BankOperation]{get}
    
    //Methods
    
    func withdrawl(value: Double) throws
    func deposit(value: Double, from account: String)
    func formattedStatement() -> String
    
    
}

enum BankAccountError: Error{
    
    case insuficentFunds(correntBalance: Double)
}

class MyBank: BankAccountProtocol{
    
    private let number: String
    private let holder: String
    private (set) var balance: Double
    private(set) var statement: [BankOperation]
    
    required init(number: String, holder: String){
        self.number = number
        self.holder = holder
        self.balance = 0.0
        self.statement = []
    }
    
    
    
        func withdrawl(value:Double) throws{
            if  self.balance>value {
                balance = balance-value
                self.statement.append(BankOperation.withdrawl(value:value))
            }

            else {
                throw BankAccountError.insuficenteFunds(currentBalance:balance)  }
            
    }
    
    func deposit(value: Double, from account: String) {
        self.balance = balance+value;
        self.statement.append(BankOperation.deposit(from:account,value:value))
       
    }
    
    func formattedStatement( ) -> String {
        
        
        var stringResul = " OPER VALUE    FROM\n"
        for stat in self.statement{
            switch stat {
            case let .deposit(from ,value):
                stringResul += "Dep " + String(value) + "    " + from + "\n"
            case let .withdrawl(value):
                stringResul += "WTH    " + String(value) + "\n"
            }
        }
        return stringResul


    }
    enum BankAccountError: Error {
        case insuficenteFunds(currentBalance: Double)
        
    }
    
   
  
    
    func test(number:String,holder:String,balance:Double) throws{
        let conta = MyBank(number:"1234",holder:"Amanda")
        self.balance = conta.balance
        
    do{

        try withdrawl(value:30.0)
        print("Saque efetuado com sucesso")
    }catch{
        BankAccountError.insuficenteFunds(currentBalance: balance)
    print("Saldo insuficiente")
    }
        conta.deposit(value: 10.0, from: "1234")
        

}
    
    
}
